## Company Synopsis
This project is based on a Lockheed Martin Orlando-style pilot training simulator system. These simulators are used to train pilots in realistic, high-risk scenarios where immediate system response is critical. Real-time performance is essential because delays in processing sensor inputs or emergency signals could lead to unsafe training conditions. In this prototype, tasks such as sensor monitoring and emergency stop handling must meet strict deadlines to ensure safe and predictable system behavior, reflecting the requirements of real-world aerospace systems.

---

### 1. Scheduler Fit  
How do your task priorities / RTOS settings guarantee every H task’s deadline in Wokwi? Cite one timestamp pair that proves it.

The system uses a priority-based preemptive scheduler in FreeRTOS to guarantee that all hard real-time tasks meet their deadlines. The SafetyTask (priority 5) is the highest priority and is triggered by an ISR, allowing it to preempt all other tasks immediately. The SensorTask and ActuatorTask run at priorities 4 and 3 with fixed 50 ms periods using vTaskDelayUntil(), ensuring deterministic execution. For example, timing data shows the SensorTask starting at around 1200 ms and completing at about 1205 ms, which is well within its 50 ms deadline. This confirms that the scheduler consistently meets hard real-time constraints.

---

### 2. Race-Proofing  
Where could a race occur? Show the exact line(s) you protected and which primitive solved it.

A race condition could occur when multiple tasks access shared variables such as sharedThreatLevel and sharedEmergencyStop. To prevent this, a mutex (sharedMutex) is used to protect these shared resources. The protected section of code is:

xSemaphoreTake(sharedMutex, portMAX_DELAY);  
sharedEmergencyStop = true;  
sharedThreatLevel = 100;  
xSemaphoreGive(sharedMutex);

Additionally, ISR-related variables like lastIsrUs are protected using a critical section (portENTER_CRITICAL_ISR). This ensures safe concurrent access between the ISR and tasks and prevents data corruption.

---

### 3. Worst-Case Spike  
Describe the heaviest load you threw at the prototype. What margin (of time) remained before an H deadline would slip?

The heaviest load was created by increasing the potentiometer value to simulate high threat levels, which increased the computation time inside the SensorTask loop. Even under this condition, execution time remained well below the 50 ms deadline, typically under 10 ms. The SafetyTask ISR response latency was measured at only a few milliseconds, staying well within the 20 ms deadline. This leaves a timing margin of over 40 ms for periodic tasks and about 15 ms for the emergency response, demonstrating that the system remains stable under peak load.

---

### 4. Design Trade-Off  
Name one feature you didnt add (or simplified) to keep timing predictable. Why was that the right call for your chosen company?

One design trade-off was limiting the complexity of the communication system and using UART (Serial) instead of WiFi or BLE. Adding wireless communication would introduce unpredictable delays and increase system overhead, making it harder to guarantee real-time deadlines. By keeping communication simple and periodic, the system ensures that all hard real-time tasks remain deterministic. This decision is appropriate for a safety-critical system where timing reliability is more important than feature complexity.


---

### AI Useage 
https://chatgpt.com/share/69ebb45e-0efc-83ea-a253-970847efef5fhttps://chatgpt.com/share/69ebb45e-0efc-83ea-a253-970847efef5f
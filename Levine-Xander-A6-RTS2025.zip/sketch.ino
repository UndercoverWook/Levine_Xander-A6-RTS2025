#include <Arduino.h>

// =====================================================
// Real-Time Systems Prototype
// Company: Lockheed Martin Orlando
// Scenario: Pilot training simulator safety monitor
// Board: ESP32 in Wokwi
// =====================================================

// ---------------- Hardware Pins ----------------
#define PIN_POT_SENSOR   34
#define PIN_ESTOP_BTN    18

#define PIN_LED_SAFE     5
#define PIN_LED_WARN     16
#define PIN_LED_DANGER   4
#define PIN_LED_HEART    17

// Logic analyzer proof pins
#define PIN_LA_SENSOR    25   // D0
#define PIN_LA_SAFETY    26   // D1
#define PIN_LA_ACTUATOR  27   // D2
#define PIN_LA_COMMS     14   // D3

// ---------------- Timing Requirements ----------------
// H = Hard real-time, S = Soft real-time
#define SENSOR_PERIOD_MS     50
#define ACTUATOR_PERIOD_MS   50
#define ESTOP_DEADLINE_MS    20
#define HEARTBEAT_PERIOD_MS  250
#define COMMS_PERIOD_MS      500
#define RESET_PERIOD_MS      1000

// ---------------- FreeRTOS Handles ----------------
QueueHandle_t sensorQueue;
QueueHandle_t logQueue;

SemaphoreHandle_t estopSem;
SemaphoreHandle_t sharedMutex;
SemaphoreHandle_t serialMutex;

portMUX_TYPE isrMux = portMUX_INITIALIZER_UNLOCKED;

// ---------------- Shared ISR Data ----------------
volatile uint32_t lastIsrUs = 0;
volatile uint32_t lastButtonUs = 0;
volatile uint32_t estopCount = 0;

// ---------------- Shared System State ----------------
int sharedThreatLevel = 0;
bool sharedEmergencyStop = false;

// ---------------- Data Packets ----------------
struct SensorPacket {
  uint32_t timestampMs;
  int rawAdc;
  int threatLevel;
};

struct LogPacket {
  uint32_t timestampMs;
  char message[128];
};

// =====================================================
// Helper Functions
// =====================================================

void queueLog(const char *msg) {
  LogPacket packet;
  packet.timestampMs = millis();
  snprintf(packet.message, sizeof(packet.message), "%s", msg);
  xQueueSend(logQueue, &packet, 0);
}

void setStatusLights(int threat, bool emergency) {
  if (emergency || threat >= 75) {
    digitalWrite(PIN_LED_SAFE, LOW);
    digitalWrite(PIN_LED_WARN, LOW);
    digitalWrite(PIN_LED_DANGER, HIGH);
  } 
  else if (threat >= 45) {
    digitalWrite(PIN_LED_SAFE, LOW);
    digitalWrite(PIN_LED_WARN, HIGH);
    digitalWrite(PIN_LED_DANGER, LOW);
  } 
  else {
    digitalWrite(PIN_LED_SAFE, HIGH);
    digitalWrite(PIN_LED_WARN, LOW);
    digitalWrite(PIN_LED_DANGER, LOW);
  }
}

// =====================================================
// ISR: Emergency Stop Button
// Hard real-time event source
// Uses binary semaphore to wake SafetyTask
// =====================================================

void IRAM_ATTR estopISR() {
  BaseType_t xHigherPriorityTaskWoken = pdFALSE;

  uint32_t nowUs = micros();

  // Debounce: ignore button noise within 200 ms
  if ((nowUs - lastButtonUs) < 200000) {
    return;
  }

  portENTER_CRITICAL_ISR(&isrMux);
  lastButtonUs = nowUs;
  lastIsrUs = nowUs;
  estopCount++;
  portEXIT_CRITICAL_ISR(&isrMux);

  xSemaphoreGiveFromISR(estopSem, &xHigherPriorityTaskWoken);

  if (xHigherPriorityTaskWoken == pdTRUE) {
    portYIELD_FROM_ISR();
  }
}

// =====================================================
// SensorTask
// H task
// Period: 50 ms
// Deadline: 50 ms
// Use-case: Reads simulator threat/proximity sensor
// =====================================================

void SensorTask(void *pvParameters) {
  TickType_t lastWake = xTaskGetTickCount();

  while (true) {
    uint32_t startMs = millis();
    digitalWrite(PIN_LA_SENSOR, HIGH);

    int raw = analogRead(PIN_POT_SENSOR);
    int threat = map(raw, 0, 4095, 0, 100);

    // Variable execution time requirement.
    // Larger threat means heavier simulated processing.
    volatile int dummy = 0;
    int work = map(threat, 0, 100, 300, 2500);
    for (int i = 0; i < work; i++) {
      dummy += i;
    }

    SensorPacket packet;
    packet.timestampMs = millis();
    packet.rawAdc = raw;
    packet.threatLevel = threat;

    xQueueOverwrite(sensorQueue, &packet);

    uint32_t endMs = millis();
    uint32_t execMs = endMs - startMs;

    char msg[128];
    snprintf(msg, sizeof(msg),
             "[%lu ms] SENSOR H start=%lu end=%lu exec=%lu deadline=50 threat=%d %s",
             endMs, startMs, endMs, execMs, threat,
             execMs <= SENSOR_PERIOD_MS ? "PASS" : "MISS");
    queueLog(msg);

    digitalWrite(PIN_LA_SENSOR, LOW);

    vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(SENSOR_PERIOD_MS));
  }
}

// =====================================================
// SafetyTask
// H task
// Event-driven by ISR
// Deadline: 20 ms after button press
// Use-case: Emergency stop safety path
// =====================================================

void SafetyTask(void *pvParameters) {
  while (true) {
    if (xSemaphoreTake(estopSem, portMAX_DELAY) == pdTRUE) {
      uint32_t handledUs = micros();
      uint32_t handledMs = millis();

      uint32_t isrUsCopy;
      uint32_t countCopy;

      portENTER_CRITICAL(&isrMux);
      isrUsCopy = lastIsrUs;
      countCopy = estopCount;
      portEXIT_CRITICAL(&isrMux);

      digitalWrite(PIN_LA_SAFETY, HIGH);

      xSemaphoreTake(sharedMutex, portMAX_DELAY);
      sharedEmergencyStop = true;
      sharedThreatLevel = 100;
      setStatusLights(sharedThreatLevel, sharedEmergencyStop);
      xSemaphoreGive(sharedMutex);

      uint32_t latencyMs = (handledUs - isrUsCopy) / 1000;

      char msg[128];
      snprintf(msg, sizeof(msg),
               "[%lu ms] ESTOP H latency=%lu deadline=20 count=%lu %s",
               handledMs, latencyMs, countCopy,
               latencyMs <= ESTOP_DEADLINE_MS ? "PASS" : "MISS");
      queueLog(msg);

      digitalWrite(PIN_LA_SAFETY, LOW);
    }
  }
}

// =====================================================
// ActuatorTask
// H task
// Period: 50 ms
// Deadline: 50 ms
// Use-case: Updates simulator warning indicators
// =====================================================

void ActuatorTask(void *pvParameters) {
  TickType_t lastWake = xTaskGetTickCount();

  while (true) {
    uint32_t startMs = millis();
    digitalWrite(PIN_LA_ACTUATOR, HIGH);

    SensorPacket packet;

    if (xQueueReceive(sensorQueue, &packet, 0) == pdTRUE) {
      xSemaphoreTake(sharedMutex, portMAX_DELAY);

      if (!sharedEmergencyStop) {
        sharedThreatLevel = packet.threatLevel;
      }

      setStatusLights(sharedThreatLevel, sharedEmergencyStop);

      xSemaphoreGive(sharedMutex);
    }

    uint32_t endMs = millis();
    uint32_t execMs = endMs - startMs;

    char msg[128];
    snprintf(msg, sizeof(msg),
             "[%lu ms] ACTUATOR H start=%lu end=%lu exec=%lu deadline=50 %s",
             endMs, startMs, endMs, execMs,
             execMs <= ACTUATOR_PERIOD_MS ? "PASS" : "MISS");
    queueLog(msg);

    digitalWrite(PIN_LA_ACTUATOR, LOW);

    vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(ACTUATOR_PERIOD_MS));
  }
}

// =====================================================
// CommsTask
// S task
// Period: 500 ms
// Deadline: Soft 500 ms
// Use-case: UART external diagnostic link
// =====================================================

void CommsTask(void *pvParameters) {
  TickType_t lastWake = xTaskGetTickCount();

  while (true) {
    uint32_t startMs = millis();
    digitalWrite(PIN_LA_COMMS, HIGH);

    LogPacket packet;
    int burstCount = 0;

    while ((burstCount < 10) && (xQueueReceive(logQueue, &packet, 0) == pdTRUE)) {
      if (xSemaphoreTake(serialMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
        Serial.print("[UART OUT] ");
        Serial.println(packet.message);
        xSemaphoreGive(serialMutex);
      }
      burstCount++;
    }

    uint32_t endMs = millis();

    if (xSemaphoreTake(serialMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
      Serial.printf("[UART OUT] [%lu ms] COMMS S burst=%d exec=%lu deadline=500\n",
                    endMs, burstCount, endMs - startMs);
      xSemaphoreGive(serialMutex);
    }

    digitalWrite(PIN_LA_COMMS, LOW);

    vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(COMMS_PERIOD_MS));
  }
}

// =====================================================
// HeartbeatTask
// S task
// Period: 250 ms
// Deadline: Soft 250 ms
// Use-case: Shows firmware is alive
// =====================================================

void HeartbeatTask(void *pvParameters) {
  TickType_t lastWake = xTaskGetTickCount();
  bool state = false;

  while (true) {
    state = !state;
    digitalWrite(PIN_LED_HEART, state);

    char msg[128];
    snprintf(msg, sizeof(msg),
             "[%lu ms] HEARTBEAT S alive deadline=250",
             millis());
    queueLog(msg);

    vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(HEARTBEAT_PERIOD_MS));
  }
}

// =====================================================
// ResetMonitorTask
// S task
// Period: 1000 ms
// Deadline: Soft 1000 ms
// Use-case: Clears emergency only after threat is safe
// =====================================================

void ResetMonitorTask(void *pvParameters) {
  TickType_t lastWake = xTaskGetTickCount();

  while (true) {
    int raw = analogRead(PIN_POT_SENSOR);
    int threat = map(raw, 0, 4095, 0, 100);
    bool cleared = false;

    xSemaphoreTake(sharedMutex, portMAX_DELAY);

    if (sharedEmergencyStop && threat < 20) {
      sharedEmergencyStop = false;
      sharedThreatLevel = threat;
      setStatusLights(sharedThreatLevel, sharedEmergencyStop);
      cleared = true;
    }

    xSemaphoreGive(sharedMutex);

    if (cleared) {
      queueLog("RESET S emergency cleared because sensor returned below 20");
    }

    vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(RESET_PERIOD_MS));
  }
}

// =====================================================
// Setup
// =====================================================

void setup() {
   Serial.begin(115200);
  delay(1000);

  Serial.println("SYSTEM STARTED");  // <<< FORCE OUTPUT

  pinMode(PIN_POT_SENSOR, INPUT);
  pinMode(PIN_ESTOP_BTN, INPUT_PULLUP);

  pinMode(PIN_LED_SAFE, OUTPUT);
  pinMode(PIN_LED_WARN, OUTPUT);
  pinMode(PIN_LED_DANGER, OUTPUT);
  pinMode(PIN_LED_HEART, OUTPUT);

  pinMode(PIN_LA_SENSOR, OUTPUT);
  pinMode(PIN_LA_SAFETY, OUTPUT);
  pinMode(PIN_LA_ACTUATOR, OUTPUT);
  pinMode(PIN_LA_COMMS, OUTPUT);

  digitalWrite(PIN_LA_SENSOR, LOW);
  digitalWrite(PIN_LA_SAFETY, LOW);
  digitalWrite(PIN_LA_ACTUATOR, LOW);
  digitalWrite(PIN_LA_COMMS, LOW);

  digitalWrite(PIN_LED_SAFE, HIGH);
  digitalWrite(PIN_LED_WARN, LOW);
  digitalWrite(PIN_LED_DANGER, LOW);
  digitalWrite(PIN_LED_HEART, LOW);

  sensorQueue = xQueueCreate(1, sizeof(SensorPacket));
  logQueue = xQueueCreate(30, sizeof(LogPacket));

  estopSem = xSemaphoreCreateBinary();
  sharedMutex = xSemaphoreCreateMutex();
  serialMutex = xSemaphoreCreateMutex();

  if (!sensorQueue || !logQueue || !estopSem || !sharedMutex || !serialMutex) {
    Serial.println("ERROR: Failed to create RTOS objects.");
    while (true) {
      delay(1000);
    }
  }

  attachInterrupt(digitalPinToInterrupt(PIN_ESTOP_BTN), estopISR, FALLING);

  Serial.println("======================================");
  Serial.println("Lockheed Martin Orlando RTS Prototype");
  Serial.println("Pilot Training Simulator Safety Monitor");
  Serial.println("UART is the external communication link.");
  Serial.println("Logic Analyzer:");
  Serial.println("D0 = SensorTask GPIO25");
  Serial.println("D1 = SafetyTask GPIO26");
  Serial.println("D2 = ActuatorTask GPIO27");
  Serial.println("D3 = CommsTask GPIO14");
  Serial.println("======================================");

  xTaskCreatePinnedToCore(SafetyTask, "SafetyTask", 4096, NULL, 5, NULL, 1);
  xTaskCreatePinnedToCore(SensorTask, "SensorTask", 4096, NULL, 4, NULL, 1);
  xTaskCreatePinnedToCore(ActuatorTask, "ActuatorTask", 4096, NULL, 3, NULL, 1);
  xTaskCreatePinnedToCore(CommsTask, "CommsTask", 4096, NULL, 2, NULL, 1);
  xTaskCreatePinnedToCore(HeartbeatTask, "HeartbeatTask", 2048, NULL, 1, NULL, 1);
  xTaskCreatePinnedToCore(ResetMonitorTask, "ResetTask", 2048, NULL, 1, NULL, 1);
}

// =====================================================
// Loop unused because FreeRTOS tasks run the system
// =====================================================

void loop() {
  vTaskDelay(portMAX_DELAY);
}